from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET
from _pytest.junitxml import mangle_test_address


def pytest_collection_modifyitems(config, items):
    seed = json.loads(Path(os.environ["OC_VERIFIED_TEST_SEED"]).read_text())
    verified = {(x["classname"], x["name"]): x for x in seed["passed"]}
    # Later receipts cover the repaired fixture-dependent modules.
    for source in filter(None, os.environ.get("OC_EXTRA_VERIFIED_XML", "").split(os.pathsep)):
        for case in ET.parse(source).getroot().iter("testcase"):
            if any(case.find(tag) is not None for tag in ("failure", "error", "skipped")):
                continue
            verified[(case.get("classname"), case.get("name"))] = {"receipt": source}
    keep, done, coverage = [], [], []
    for item in items:
        names = mangle_test_address(item.nodeid)
        key = (".".join(names[:-1]), names[-1])
        record = verified.get(key)
        digest = hashlib.sha256(Path(str(item.path)).read_bytes()).hexdigest()
        force = item.nodeid in {"tests/test_cockpit_quota.py::test_no_credentials_short_circuits_without_network_attempt", "tests/test_cockpit_quota.py::test_env_token_present_succeeds_without_probing_other_sources", "tests/test_cockpit_agents.py::test_subagents_degrade_to_none_when_tree_absent"}
        reusable = not force and record is not None and ("sha256" not in record or record["sha256"] == digest)
        (done if reusable else keep).append(item)
        coverage.append({"nodeid": item.nodeid, "classname": key[0], "name": key[1], "sha256": digest, "reused_pass": reusable, "receipt": record.get("receipt") if reusable else None})
    Path(os.environ["OC_TEST_COVERAGE"]).write_text(json.dumps(coverage, indent=2) + "\n")
    items[:] = keep
    config.hook.pytest_deselected(items=done)


def pytest_runtest_logreport(report):
    target = os.environ.get("OC_TEST_EVENTS")
    if target:
        event = {"nodeid": report.nodeid, "when": report.when, "outcome": report.outcome, "duration": report.duration}
        if report.failed:
            event["failure"] = str(report.longrepr)
        with Path(target).open("a") as stream:
            stream.write(json.dumps(event) + "\n")
