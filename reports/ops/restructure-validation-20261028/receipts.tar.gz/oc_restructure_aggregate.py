from pathlib import Path
from collections import Counter
from datetime import datetime, UTC
import hashlib,json,xml.etree.ElementTree as ET
root=Path('/root/codex-test/open-composer')
expected=json.loads(Path('/tmp/oc-restructure-test-coverage3.json').read_text())
records={}
seed=json.loads(Path('/tmp/oc-verified-test-seed3.json').read_text())
for x in seed['passed']:
 p=root/x['file']
 if p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256']:
  records[(x['classname'],x['name'])]={'status':'passed','receipt':x['receipt'],'test_source_sha256':x['sha256']}
receipts=['/tmp/oc-current-paper-fixture-retest.xml','/tmp/oc-current-paper-fixture-guards.xml','/tmp/oc-source-runtime-fixture-retest.xml','/tmp/oc-restructure-remaining-tests3.xml','/tmp/oc-paper-final-fixtures.xml','/tmp/oc-restructure-last-fixtures.xml']
for path in receipts:
 for c in ET.parse(path).getroot().iter('testcase'):
  # Reused native guard proofs are stronger than a portable skip, not replaced by it.
  failure=c.find('failure');error=c.find('error');skip=c.find('skipped')
  status='failed' if failure is not None or error is not None else ('skipped' if skip is not None else 'passed')
  key=(c.get('classname'),c.get('name'))
  if status=='skipped' and records.get(key,{}).get('status')=='passed':continue
  records[key]={'status':status,'receipt':path}
  if skip is not None:records[key]['reason']=skip.get('message')
missing=[]; rows=[]
for item in expected:
 key=(item['classname'],item['name']);r=records.get(key)
 if r is None:missing.append(item['nodeid']);r={'status':'missing'}
 rows.append({'nodeid':item['nodeid'],**r})
counts=Counter(x['status'] for x in rows)
print(json.dumps({'counts':dict(counts),'missing':missing,'failed':[x['nodeid'] for x in rows if x['status']=='failed'],'skips':dict(Counter(x.get('reason') for x in rows if x['status']=='skipped'))},ensure_ascii=False,indent=2))
out={'recorded_at':datetime.now(UTC).isoformat(),'collected_cases':len(expected),'counts':dict(counts),'method':'Serial batches with unchanged-test-source hashes, complete affected-file retests and immutable per-case receipts. Three portable fixture followups and actual native-resource proof are included; cases are deduplicated by collected node identity.','incomplete_batch_note':'SIP archive setup could not unwind on SIGINT. Prior terminal outcomes were paired with captured collection and unchanged source hashes; its pending case was never counted. Receipt is oc-restructure-interrupted-progress.json.','native_resource':'11 physical cases passed under actual CPU0/400MiB/zero swap; make test-native-resource also exited0.','renamed_retired_contract_tests':{'tests/test_research_control.py::test_claude_prompt_hook_injects_memory_from_real_paths':'tests/test_research_control.py::test_claude_shared_entry_keeps_legacy_prompt_hook_archived','tests/test_research_direction_autonomy.py::test_chinese_prompt_injects_documented_context_not_rewritten_prompt':'tests/test_research_direction_autonomy.py::test_chinese_brief_is_preserved_in_neutral_workflow'},'cases':rows}
Path('/tmp/oc-restructure-test-aggregate.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
